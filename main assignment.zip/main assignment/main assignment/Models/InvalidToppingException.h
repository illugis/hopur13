//
//  InvalidToppingException.h
//  main assignment
//
//  Created by Gunnlaugur Birgisson on 08/12/2017.
//  Copyright (c) 2017 Bloc. All rights reserved.
//

#ifndef __main_assignment__InvalidToppingException__
#define __main_assignment__InvalidToppingException__

#include <stdio.h>

class InvalidToppingException { };

#endif /* defined(__main_assignment__InvalidToppingException__) */
