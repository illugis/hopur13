//
//  InvalidSizeExceptions.h
//  main assignment
//
//  Created by Gunnlaugur Birgisson on 07/12/2017.
//  Copyright (c) 2017 Bloc. All rights reserved.
//

#ifndef __main_assignment__InvalidSizeExceptions__
#define __main_assignment__InvalidSizeExceptions__

#include <stdio.h>

class InvalidCrustPriceException { };

#endif /* defined(__main_assignment__InvalidSizeExceptions__) */
