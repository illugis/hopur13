//
//  InvalidDestinationException.h
//  main assignment
//
//  Created by Gunnlaugur Birgisson on 08/12/2017.
//  Copyright (c) 2017 Bloc. All rights reserved.
//

#ifndef __main_assignment__InvalidDestinationException__
#define __main_assignment__InvalidDestinationException__

#include <stdio.h>

class InvalidDestinationException { };

#endif /* defined(__main_assignment__InvalidDestinationException__) */
