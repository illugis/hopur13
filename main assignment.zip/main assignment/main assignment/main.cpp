//
//  main.cpp
//  main assignment
//
//  Created by Gunnlaugur Birgisson on 27/11/2017.
//  Copyright (c) 2017 Bloc. All rights reserved.
//

#include "mainui.h"

#include <iostream>

using namespace std;

int main() {
    
    MainUI mainui;
    
    mainui.startUI();
    
    /*
     
     Hópur 13
     
     Gunnlaugur H. Birgisson
     Illugi Steingrímsson
    
    */
     
    return 0;
}
