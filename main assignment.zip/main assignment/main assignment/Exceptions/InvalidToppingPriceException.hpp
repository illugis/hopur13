//
//  InvalidToppingPriceException.hpp
//  main assignment
//
//  Created by illugi steingrimsson on 13/12/2017.
//  Copyright © 2017 Bloc. All rights reserved.
//

#ifndef InvalidToppingPriceException_hpp
#define InvalidToppingPriceException_hpp

#include <stdio.h>

class InvalidToppingPriceException {
    
};

#endif /* InvalidToppingPriceException_hpp */
