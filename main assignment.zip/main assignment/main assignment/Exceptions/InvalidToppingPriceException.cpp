//
//  InvalidToppingPriceException.cpp
//  main assignment
//
//  Created by illugi steingrimsson on 13/12/2017.
//  Copyright © 2017 Bloc. All rights reserved.
//

#include "InvalidToppingPriceException.hpp"
