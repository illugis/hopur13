//
//  InvalidOtherPriceException.hpp
//  main assignment
//
//  Created by illugi steingrimsson on 13/12/2017.
//  Copyright © 2017 Bloc. All rights reserved.
//

#ifndef InvalidOtherPriceException_hpp
#define InvalidOtherPriceException_hpp

#include <stdio.h>

class InvalidOtherPriceException { };

#endif /* InvalidOtherPriceException_hpp */
