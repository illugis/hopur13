//
//  InvalidOtherException.hpp
//  main assignment
//
//  Created by illugi steingrimsson on 13/12/2017.
//  Copyright © 2017 Bloc. All rights reserved.
//

#ifndef InvalidOtherException_hpp
#define InvalidOtherException_hpp

#include <stdio.h>

class InvalidOtherException { };

#endif /* InvalidOtherException_hpp */
