//
//  MainUIService.h
//  main assignment
//
//  Created by Gunnlaugur Birgisson on 06/12/2017.
//  Copyright (c) 2017 Bloc. All rights reserved.
//

#ifndef __main_assignment__MainUIService__
#define __main_assignment__MainUIService__

#include "mainui.h"

#include <iostream>

class MainUIService {
    
};

#endif /* defined(__main_assignment__MainUIService__) */
